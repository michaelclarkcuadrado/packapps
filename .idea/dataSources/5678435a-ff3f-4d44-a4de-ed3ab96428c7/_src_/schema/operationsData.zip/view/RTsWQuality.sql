CREATE VIEW RTsWQuality AS
  SELECT
    `operationsData`.`BULKOHCSV`.`RT#`                                                                AS `RT#`,
    `operationsData`.`BULKOHCSV`.`SortCode`                                                           AS `SortCode`,
    `operationsData`.`BULKOHCSV`.`CropYear`                                                           AS `Crop Year`,
    `operationsData`.`BULKOHCSV`.`Grower`                                                             AS `Grower`,
    `operationsData`.`BULKOHCSV`.`GrowerName`                                                         AS `Grower Name`,
    `operationsData`.`BULKOHCSV`.`Class`                                                              AS `Class`,
    `operationsData`.`BULKOHCSV`.`ClassDesc`                                                          AS `Class Desc`,
    `operationsData`.`BULKOHCSV`.`Commodity`                                                          AS `Commodity`,
    `operationsData`.`BULKOHCSV`.`CommDesc`                                                           AS `CommDesc`,
    `operationsData`.`BULKOHCSV`.`Variety`                                                            AS `Variety`,
    `operationsData`.`BULKOHCSV`.`VarDesc`                                                            AS `Var Desc`,
    `operationsData`.`BULKOHCSV`.`Strain`                                                             AS `Strain`,
    `operationsData`.`BULKOHCSV`.`StrDesc`                                                            AS `Str Desc`,
    `operationsData`.`BULKOHCSV`.`Farm`                                                               AS `Farm`,
    (CASE WHEN (`operationsData`.`BULKOHCSV`.`FarmDesc` = '')
      THEN '[Farm Name]'
     ELSE `operationsData`.`BULKOHCSV`.`FarmDesc` END)                                                AS `Farm Desc`,
    `operationsData`.`BULKOHCSV`.`Block`                                                              AS `Block`,
    (CASE WHEN (`operationsData`.`BULKOHCSV`.`BlockDesc` = '')
      THEN '[Block Name]'
     ELSE `operationsData`.`BULKOHCSV`.`BlockDesc` END)                                               AS `Block Desc`,
    `operationsData`.`BULKOHCSV`.`Lot`                                                                AS `Lot`,
    `operationsData`.`BULKOHCSV`.`Date`                                                               AS `Date`,
    `operationsData`.`BULKOHCSV`.`Size`                                                               AS `Size`,
    `operationsData`.`BULKOHCSV`.`Pack`                                                               AS `Pack`,
    `operationsData`.`BULKOHCSV`.`QtyOnHand`                                                          AS `QtyOnHand`,
    `operationsData`.`BULKOHCSV`.`BuOnHand`                                                           AS `BuOnHand`,
    `operationsData`.`BULKOHCSV`.`RoomNum`                                                            AS `Location`,
    `operationsData`.`BULKOHCSV`.`CoNum`                                                              AS `Co#`,
    `operationsData`.`BULKOHCSV`.`Company Name`                                                       AS `Company Name`,
    (CASE WHEN isnull(`operationsData`.`InspectedRTs`.`Color Quality`)
      THEN 'FALSE'
     ELSE 'TRUE' END)                                                                                 AS `isQA`,
    (CASE WHEN isnull(`operationsData`.`AppleSamples`.`PrAvg`)
      THEN ''
     ELSE round(avg(`operationsData`.`AppleSamples`.`PrAvg`), 3) END)                                 AS `PressureAvg`,
    (CASE WHEN isnull(`operationsData`.`AppleSamples`.`DAAvg`)
      THEN ''
     ELSE round(avg(`operationsData`.`AppleSamples`.`DAAvg`), 2) END)                                 AS `DAAvg`,
    ifnull(round(avg(`operationsData`.`AppleSamples`.`Brix`), 2), '')                                 AS `Brix`,
    ifnull(round(avg(`operationsData`.`AppleSamples`.`Starch`), 1), '')                               AS `Starch`,
    ifnull(concat(`operationsData`.`InspectedRTs`.`Color Quality`,
                  convert((CASE WHEN (`operationsData`.`InspectedRTs`.`Blush` <> 0)
                    THEN ' With Blush'
                           ELSE '' END) USING latin1)), '')                                           AS `Color`,
    ifnull(`operationsData`.`InspectedRTs`.`Bruise`, '')                                              AS `Bruise`,
    (CASE WHEN isnull(`operationsData`.`InspectedRTs`.`BitterPit`)
      THEN ''
     ELSE (CASE WHEN (`operationsData`.`InspectedRTs`.`BitterPit` <> 0)
       THEN 'Present'
           ELSE 'Not Present' END) END)                                                               AS `BitterPit`,
    ifnull(`operationsData`.`InspectedRTs`.`Russet`, '')                                              AS `Russet`,
    ifnull(`operationsData`.`InspectedRTs`.`SunBurn`, '')                                             AS `Sunburn`,
    ifnull(`operationsData`.`InspectedRTs`.`SanJoseScale`,
           '')                                                                                        AS `San Jose Scale`,
    ifnull(`operationsData`.`InspectedRTs`.`Scab`, '')                                                AS `Scab`,
    ifnull(`operationsData`.`InspectedRTs`.`StinkBug`, '')                                            AS `StinkBug`,
    ifnull(round(`AvgWeightByRT`.`WeightAvg`, 2),
           '')                                                                                        AS `AverageWeight`,
    (CASE WHEN isnull(`AvgWeightByRT`.`WeightAvg`)
      THEN ''
     ELSE (CASE WHEN ((`AvgWeightByRT`.`WeightAvg` * 16) >= 13)
       THEN 48
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 13) AND (`AvgWeightByRT`.`WeightAvg` >= 11.15))
             THEN 56
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 11.15) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 9.9))
             THEN 64
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 9.9) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 8.85))
             THEN 72
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 8.85) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 8))
             THEN 80
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 8) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 7.15))
             THEN 88
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 7.15) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 6.3))
             THEN 100
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 6.3) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 5.65))
             THEN 113
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 5.65) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 5.1))
             THEN 125
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 5.1) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 4.65))
             THEN 138
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 4.65) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 4.3))
             THEN 150
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 4.3) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 3.95))
             THEN 163
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 3.95) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 3.6))
             THEN 175
           WHEN (((`AvgWeightByRT`.`WeightAvg` * 16) < 3.6) AND ((`AvgWeightByRT`.`WeightAvg` * 16) >= 3.25))
             THEN 198
           ELSE 216 END) END)                                                                         AS `SizefromAverage`,
    ifnull(`operationsData`.`InspectedRTs`.`Note`, '')                                                AS `Notes`,
    (CASE WHEN isnull(`operationsData`.`InspectedRTs`.`InspectedBy`)
      THEN ''
     ELSE concat('Field Inspector: ', `operationsData`.`InspectedRTs`.`InspectedBy`, '-- Final Inspector: ',
                 ifnull(`operationsData`.`AppleSamples`.`FinalTestedBy`, 'Not Final Inspected')) END) AS `InspectedBy`,
    ifnull(`operationsData`.`AppleSamples`.`FinalInspectionDate`,
           ifnull(`operationsData`.`InspectedRTs`.`DateInspected`, ''))                               AS `DateTested`
  FROM (((`operationsData`.`BULKOHCSV`
    LEFT JOIN `operationsData`.`InspectedRTs`
      ON ((`operationsData`.`BULKOHCSV`.`RT#` = `operationsData`.`InspectedRTs`.`RTNum`))) LEFT JOIN
    `operationsData`.`AppleSamples`
      ON ((`operationsData`.`InspectedRTs`.`RTNum` = `operationsData`.`AppleSamples`.`RT#`))) LEFT JOIN
    `operationsData`.`AvgWeightByRT` ON ((`AvgWeightByRT`.`RTNum` = `operationsData`.`BULKOHCSV`.`RT#`)))
  GROUP BY `operationsData`.`BULKOHCSV`.`RT#`;
