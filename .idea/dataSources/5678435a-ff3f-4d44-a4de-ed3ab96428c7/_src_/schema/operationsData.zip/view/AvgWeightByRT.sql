CREATE VIEW AvgWeightByRT AS
  SELECT
    `operationsData`.`InspectedRTs`.`RTNum`                             AS `RTNum`,
    (CASE WHEN (`operationsData`.`AggregateWeightSamples`.`Weight` IS NOT NULL)
      THEN (((sum(`operationsData`.`InspectedRTs`.`#Samples`) * avg(`operationsData`.`AppleSamples`.`Weight`)) +
             ((20 * count(`operationsData`.`AggregateWeightSamples`.`RT#`)) *
              avg((`operationsData`.`AggregateWeightSamples`.`Weight` / 20)))) /
            (sum(`operationsData`.`InspectedRTs`.`#Samples`) +
             (20 * count(`operationsData`.`AggregateWeightSamples`.`RT#`))))
     ELSE ifnull(avg(`operationsData`.`AppleSamples`.`Weight`), 0) END) AS `WeightAvg`
  FROM ((`operationsData`.`InspectedRTs`
    LEFT JOIN `operationsData`.`AppleSamples`
      ON ((`operationsData`.`InspectedRTs`.`RTNum` = `operationsData`.`AppleSamples`.`RT#`))) LEFT JOIN
    `operationsData`.`AggregateWeightSamples`
      ON ((`operationsData`.`InspectedRTs`.`RTNum` = `operationsData`.`AggregateWeightSamples`.`RT#`)))
  GROUP BY `operationsData`.`InspectedRTs`.`RTNum`;
