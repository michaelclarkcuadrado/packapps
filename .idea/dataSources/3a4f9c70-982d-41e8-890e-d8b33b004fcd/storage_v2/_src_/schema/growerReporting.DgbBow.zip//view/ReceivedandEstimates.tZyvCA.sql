create view ReceivedandEstimates as (select
                                       rtrim(`growerReporting`.`crop-estimates`.`PK`)        AS `BlockID`,
                                       rtrim(`growerReporting`.`crop-estimates`.`Grower`)    AS `Code`,
                                       rtrim(`growerReporting`.`crop-estimates`.`Comm Desc`) AS `Commodity`,
                                       rtrim(`growerReporting`.`crop-estimates`.`FarmDesc`)  AS `Farm`,
                                       ifnull(rtrim(`CurYearReceived`.`Farm`), '')           AS `FarmCode`,
                                       rtrim(`growerReporting`.`crop-estimates`.`BlockDesc`) AS `Block`,
                                       ifnull(rtrim(`CurYearReceived`.`Block`), '')          AS `BlockCode`,
                                       rtrim(`growerReporting`.`crop-estimates`.`VarDesc`)   AS `Variety`,
                                       rtrim(`growerReporting`.`crop-estimates`.`Str Desc`)  AS `Strain`,
                                       rtrim(`growerReporting`.`crop-estimates`.`2015act`)   AS `2015 Received`,
                                       rtrim(`growerReporting`.`crop-estimates`.`2016act`)   AS `2016 Received`,
                                       rtrim(`growerReporting`.`crop-estimates`.`2017act`)   AS `2017 Received`,
                                       rtrim(case when `growerReporting`.`crop-estimates`.`isDeleted` = 0
                                         then `growerReporting`.`crop-estimates`.`2017est`
                                             else 0 end)                                     AS `2017 Estimate`,
                                       ifnull(sum(`CurYearReceived`.`Bu`), '0')              AS `2018 Received`,
                                       case when `growerReporting`.`crop-estimates`.`isDeleted` = 0
                                         then 'false'
                                       else 'true' end                                       AS `isDeletedBlock`,
                                       case when `growerReporting`.`crop-estimates`.`isFinished` = 0
                                         then 'false'
                                       else 'true' end                                       AS `isDonePicking`,
                                       case when (`growerReporting`.`crop-estimates`.`2018est` <> `growerReporting`.`crop-estimates`.`2017act` or
                                                  `growerReporting`.`crop-estimates`.`isSameAsLastYear` = 1)
                                         then 'true'
                                       else 'false' end                                      AS `isUserConfirmedEstimate`
                                     from (`growerReporting`.`crop-estimates`
                                       left join `growerReporting`.`CurYearReceived` on (rtrim(`CurYearReceived`.`Comm Desc`) = rtrim(`growerReporting`.`crop-estimates`.`Comm Desc`) and
                                                                                         rtrim(`CurYearReceived`.`VarDesc` = rtrim(`growerReporting`.`crop-estimates`.`VarDesc`)) and
                                                                                         rtrim(`CurYearReceived`.`StrDesc` = rtrim(`growerReporting`.`crop-estimates`.`Str Desc`)) and
                                                                                         rtrim(`CurYearReceived`.`BlockDesc` = rtrim(`growerReporting`.`crop-estimates`.`BlockDesc`)) and
                                                                                         rtrim(`CurYearReceived`.`FarmDesc` = rtrim(`growerReporting`.`crop-estimates`.`FarmDesc`)) and
                                                                                         rtrim(`CurYearReceived`.`Grower` = rtrim(`growerReporting`.`crop-estimates`.`Grower`))))
                                     group by `growerReporting`.`crop-estimates`.`PK`)
                                    union (select
                                             'Unmatched Block'                                AS `BlockID`,
                                             rtrim(`growerReporting`.`BULKRTCSV`.`Grower`)    AS `Code`,
                                             rtrim(`growerReporting`.`BULKRTCSV`.`Comm Desc`) AS `Commodity`,
                                             rtrim(`growerReporting`.`BULKRTCSV`.`FarmDesc`)  AS `Farm`,
                                             rtrim(`growerReporting`.`BULKRTCSV`.`Farm`)      AS `FarmCode`,
                                             rtrim(`growerReporting`.`BULKRTCSV`.`BlockDesc`) AS `Block`,
                                             rtrim(`growerReporting`.`BULKRTCSV`.`Block`)     AS `BlockCode`,
                                             rtrim(`growerReporting`.`BULKRTCSV`.`VarDesc`)   AS `Variety`,
                                             rtrim(`growerReporting`.`BULKRTCSV`.`StrDesc`)   AS `Strain`,
                                             '0'                                              AS `2015 Received`,
                                             '0'                                              AS `2016 Received`,
                                             '0'                                              AS `2017 Received`,
                                             '0'                                              AS `2018 Estimate`,
                                             sum(`growerReporting`.`BULKRTCSV`.`Bu`)          AS `2018 Received`,
                                             'false'                                          AS `isDeletedBlock`,
                                             'false'                                          AS `isDonePicking`,
                                             'false'                                          AS `isUserConfirmedEstimate`
                                           from (`growerReporting`.`BULKRTCSV`
                                             left join `growerReporting`.`crop-estimates` on (
                                               rtrim(`growerReporting`.`BULKRTCSV`.`Comm Desc`) = rtrim(`growerReporting`.`crop-estimates`.`Comm Desc`) and
                                               rtrim(`growerReporting`.`BULKRTCSV`.`VarDesc` = rtrim(`growerReporting`.`crop-estimates`.`VarDesc`)) and
                                               rtrim(`growerReporting`.`BULKRTCSV`.`StrDesc` = rtrim(`growerReporting`.`crop-estimates`.`Str Desc`)) and
                                               rtrim(`growerReporting`.`BULKRTCSV`.`BlockDesc` = rtrim(`growerReporting`.`crop-estimates`.`BlockDesc`)) and
                                               rtrim(`growerReporting`.`BULKRTCSV`.`FarmDesc` = rtrim(`growerReporting`.`crop-estimates`.`FarmDesc`)) and
                                               rtrim(`growerReporting`.`BULKRTCSV`.`Grower` = rtrim(`growerReporting`.`crop-estimates`.`Grower`))))
                                           where `growerReporting`.`crop-estimates`.`PK` is null and `growerReporting`.`BULKRTCSV`.`Crop Year` = substr(year(curdate()), 4, 1)
                                           group by `growerReporting`.`BULKRTCSV`.`Grower`, `growerReporting`.`BULKRTCSV`.`Comm Desc`, `growerReporting`.`BULKRTCSV`.`FarmDesc`,
                                             `growerReporting`.`BULKRTCSV`.`BlockDesc`, `growerReporting`.`BULKRTCSV`.`VarDesc`, `growerReporting`.`BULKRTCSV`.`StrDesc`);

