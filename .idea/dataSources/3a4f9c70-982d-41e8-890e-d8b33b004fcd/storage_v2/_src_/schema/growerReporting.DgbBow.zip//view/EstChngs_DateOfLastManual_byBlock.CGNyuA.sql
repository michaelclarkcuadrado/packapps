create view EstChngs_DateOfLastManual_byBlock as
  select
    `A1`.`block_PK`          AS `block_PK`,
    max(`A1`.`date_Changed`) AS `Last_Date_Change`
  from `growerReporting`.`changes_this_year` `A1`
  where `A1`.`changed_by` <> 'System'
  group by `A1`.`block_PK`;

