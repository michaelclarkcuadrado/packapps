create view OrigUserEstimate_ThisYear as
  select
    `A`.`block_PK`              AS `block_PK`,
    `A`.`date_Changed`          AS `date_Changed`,
    max(`A`.`new_bushel_value`) AS `new_bushel_value`
  from (`growerReporting`.`changes_this_year` `A`
    join (select
            `A`.`block_PK`                        AS `block_PK`,
            cast(`A`.`date_Changed` as date)      AS `Orig_Estimate_Date`,
            max(cast(`A`.`date_Changed` as time)) AS `Last_Time_Changed_On_Date`
          from (`growerReporting`.`changes_this_year` `A`
            join (select
                    `A`.`block_PK`                        AS `block_PK`,
                    min(cast(`A`.`date_Changed` as date)) AS `Orig_Estimate_Date`
                  from `growerReporting`.`changes_this_year` `A`
                  where `A`.`changed_by` <> 'System'
                  group by `A`.`block_PK`) `B` on (`A`.`block_PK` = `B`.`block_PK` and cast(`A`.`date_Changed` as date) = `B`.`Orig_Estimate_Date`))
          where `A`.`changed_by` <> 'System'
          group by `A`.`block_PK`, cast(`A`.`date_Changed` as date)) `B`
      on (`A`.`block_PK` = `B`.`block_PK` and cast(`A`.`date_Changed` as date) = `B`.`Orig_Estimate_Date` and cast(`A`.`date_Changed` as time) = `B`.`Last_Time_Changed_On_Date`))
  where `A`.`changed_by` <> 'System'
  group by `A`.`block_PK`, `A`.`date_Changed`;

