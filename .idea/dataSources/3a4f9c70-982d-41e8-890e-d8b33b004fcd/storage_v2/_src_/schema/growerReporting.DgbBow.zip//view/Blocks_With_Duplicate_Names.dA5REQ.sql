create view Blocks_With_Duplicate_Names as
  select
    `A`.`Grower`         AS `Grower`,
    `A`.`FarmDesc`       AS `FarmDesc`,
    `A`.`BlockDesc`      AS `BlockDesc`,
    `A`.`Comm Desc`      AS `Comm Desc`,
    `A`.`VarDesc`        AS `VarDesc`,
    `A`.`Str Desc`       AS `Str Desc`,
    `B`.`PK`             AS `PK`,
    `B`.`isDeleted`      AS `isDeleted`,
    `B`.`2017est`        AS `2017Est`,
    `A`.`Count_Of_Block` AS `Count_Of_Block`
  from ((select
           `growerReporting`.`crop-estimates`.`Grower`    AS `Grower`,
           `growerReporting`.`crop-estimates`.`FarmDesc`  AS `FarmDesc`,
           `growerReporting`.`crop-estimates`.`BlockDesc` AS `BlockDesc`,
           `growerReporting`.`crop-estimates`.`Comm Desc` AS `Comm Desc`,
           `growerReporting`.`crop-estimates`.`VarDesc`   AS `VarDesc`,
           `growerReporting`.`crop-estimates`.`Str Desc`  AS `Str Desc`,
           count(`growerReporting`.`crop-estimates`.`PK`) AS `Count_Of_Block`
         from `growerReporting`.`crop-estimates`
         group by `growerReporting`.`crop-estimates`.`Grower`, `growerReporting`.`crop-estimates`.`FarmDesc`, `growerReporting`.`crop-estimates`.`BlockDesc`,
           `growerReporting`.`crop-estimates`.`Comm Desc`, `growerReporting`.`crop-estimates`.`VarDesc`, `growerReporting`.`crop-estimates`.`Str Desc`
         having count(`growerReporting`.`crop-estimates`.`PK`) > 1) `A` left join `growerReporting`.`crop-estimates` `B`
      on (`A`.`Grower` = `B`.`Grower` and `A`.`FarmDesc` = `B`.`FarmDesc` and `A`.`BlockDesc` = `B`.`BlockDesc` and `A`.`Comm Desc` = `B`.`Comm Desc` and `A`.`VarDesc` = `B`.`VarDesc` and
          `A`.`Str Desc` = `B`.`Str Desc`));

