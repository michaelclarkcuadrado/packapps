create view EstChngs_WithPreviousQty as
  select
    `A`.`block_PK`                                                        AS `block_PK`,
    `A`.`cropYear`                                                        AS `cropYear`,
    `A`.`Grower`                                                          AS `Grower`,
    `C`.`FarmDesc`                                                        AS `FarmDesc`,
    `C`.`BlockDesc`                                                       AS `BlockDesc`,
    `C`.`Comm Desc`                                                       AS `Comm Desc`,
    `C`.`VarDesc`                                                         AS `VarDesc`,
    `C`.`Str Desc`                                                        AS `Str Desc`,
    `B`.`date_Changed`                                                    AS `Previous_Date`,
    `A`.`date_Changed`                                                    AS `MostRecent_Date`,
    `B`.`changed_by`                                                      AS `Previous_User`,
    `A`.`changed_by`                                                      AS `MostRecent_User`,
    `B`.`new_bushel_value`                                                AS `Previous_Qty`,
    `A`.`new_bushel_value`                                                AS `MostRecent_Qty`,
    ifnull(`A`.`new_bushel_value`, 0) - ifnull(`B`.`new_bushel_value`, 0) AS `Qty_Change`
  from (((select
            `A`.`block_PK`                                                                                                                                   AS `block_PK`,
            `A`.`date_Changed`                                                                                                                               AS `date_Changed`,
            `A`.`cropYear`                                                                                                                                   AS `cropYear`,
            `A`.`belongs_to_Grower`                                                                                                                          AS `Grower`,
            `A`.`changed_by`                                                                                                                                 AS `changed_by`,
            `A`.`new_bushel_value`                                                                                                                           AS `new_bushel_value`,
            (select max(`AA`.`date_Changed`)
             from `growerReporting`.`crop_estimates_changes_timeseries` `AA`
             where `AA`.`block_PK` = `A`.`block_PK` and `AA`.`cropYear` = `A`.`cropYear` and `AA`.`date_Changed` <= subtime(`A`.`date_Changed`, '00:02:00')) AS `Previous_Date`
          from `growerReporting`.`crop_estimates_changes_timeseries` `A`) `A` left join (select
                                                                                           `AA`.`block_PK`              AS `block_PK`,
                                                                                           `AA`.`date_Changed`          AS `date_Changed`,
                                                                                           `AA`.`changed_by`            AS `changed_by`,
                                                                                           max(`AA`.`new_bushel_value`) AS `new_bushel_value`
                                                                                         from `growerReporting`.`crop_estimates_changes_timeseries` `AA`
                                                                                         group by `AA`.`block_PK`, `AA`.`date_Changed`, `AA`.`changed_by`) `B`
      on (`A`.`block_PK` = `B`.`block_PK` and `A`.`Previous_Date` = `B`.`date_Changed`)) left join `growerReporting`.`crop-estimates` `C` on (`A`.`block_PK` = `C`.`PK`));

