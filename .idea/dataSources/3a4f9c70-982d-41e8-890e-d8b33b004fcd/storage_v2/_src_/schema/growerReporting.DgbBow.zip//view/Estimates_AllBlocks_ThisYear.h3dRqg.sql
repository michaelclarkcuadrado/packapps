create view Estimates_AllBlocks_ThisYear as
  select
    `A`.`PK`               AS `block_PK`,
    `A`.`Comm Desc`        AS `Comm Desc`,
    `A`.`VarDesc`          AS `VarDesc`,
    `A`.`Str Desc`         AS `Str Desc`,
    `A`.`Grower`           AS `Grower`,
    `A`.`FarmDesc`         AS `FarmDesc`,
    `A`.`BlockDesc`        AS `BlockDesc`,
    `A`.`2016act`          AS `2016Act`,
    `A`.`2017est`          AS `2017_Est_InclUnconf`,
    `B`.`new_bushel_value` AS `2017_Est_Confirmed`,
    `B`.`changed_by`       AS `changed_by`,
    `B`.`date_Changed`     AS `date_Changed`,
    case when `A`.`isSameAsLastYear` = 1
      then 'TRUE'
    else 'FALSE' end       AS `isSameAsLastYear`,
    case when `A`.`isDeleted` = 1
      then 'TRUE'
    else 'FALSE' end       AS `isDeleted`,
    case when `A`.`isFinished` = 1
      then 'TRUE'
    else 'FALSE' end       AS `isFinished`,
    case when `B`.`new_bushel_value` is not null
      then 'TRUE'
    else 'FALSE' end       AS `isUserConfirmed`
  from (`growerReporting`.`crop-estimates` `A` left join `growerReporting`.`EstChngs_UserUpdated_ThisYear` `B` on (`A`.`PK` = `B`.`block_PK`));

