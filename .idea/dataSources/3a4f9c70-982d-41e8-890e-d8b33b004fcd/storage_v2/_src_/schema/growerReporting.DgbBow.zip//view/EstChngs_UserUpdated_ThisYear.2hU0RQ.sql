create view EstChngs_UserUpdated_ThisYear as select
                                               `A`.`block_PK`          AS `block_PK`,
                                               `A`.`Comm Desc`         AS `Comm Desc`,
                                               `A`.`VarDesc`           AS `VarDesc`,
                                               `A`.`Str Desc`          AS `Str Desc`,
                                               `A`.`belongs_to_Grower` AS `Grower`,
                                               `A`.`FarmDesc`          AS `FarmDesc`,
                                               `A`.`BlockDesc`         AS `BlockDesc`,
                                               `A`.`cropYear`          AS `cropYear`,
                                               `A`.`date_Changed`      AS `date_Changed`,
                                               `A`.`changed_by`        AS `changed_by`,
                                               `A`.`new_bushel_value`  AS `new_bushel_value`,
                                               `C`.`isSameAsLastYear`  AS `isSameAsLastYear`,
                                               `C`.`isDeleted`         AS `isDeleted`,
                                               `C`.`isFinished`        AS `isFinished`
                                             from ((`growerReporting`.`changes_this_year` `A`
                                               join `growerReporting`.`EstChngs_DateOfLastManual_byBlock` `B` on (`A`.`block_PK` = `B`.`block_PK` and `A`.`date_Changed` = `B`.`Last_Date_Change`)) join
                                               `growerReporting`.`crop-estimates` `C` on (`A`.`block_PK` = `C`.`PK`))
                                             where `C`.`isDeleted` = 0
                                             union select
                                                     `A`.`PK`               AS `block_PK`,
                                                     `A`.`Comm Desc`        AS `Comm Desc`,
                                                     `A`.`VarDesc`          AS `VarDesc`,
                                                     `A`.`Str Desc`         AS `Str Desc`,
                                                     `A`.`Grower`           AS `Grower`,
                                                     `A`.`FarmDesc`         AS `FarmDesc`,
                                                     `A`.`BlockDesc`        AS `BlockDesc`,
                                                     2017                   AS `cropYear`,
                                                     NULL                   AS `date_Changed`,
                                                     NULL                   AS `changed_by`,
                                                     `A`.`2017est`          AS `new_bushel_value`,
                                                     `A`.`isSameAsLastYear` AS `isSameAsLastYear`,
                                                     `A`.`isDeleted`        AS `isDeleted`,
                                                     `A`.`isFinished`       AS `isFinished`
                                                   from (`growerReporting`.`crop-estimates` `A` left join `growerReporting`.`EstChngs_DateOfLastManual_byBlock` `B` on (`A`.`PK` = `B`.`block_PK`))
                                                   where `A`.`isDeleted` = 0 and `A`.`isSameAsLastYear` = 1 and `B`.`block_PK` is null
                                             union select
                                                     `A`.`PK`               AS `block_PK`,
                                                     `A`.`Comm Desc`        AS `Comm Desc`,
                                                     `A`.`VarDesc`          AS `VarDesc`,
                                                     `A`.`Str Desc`         AS `Str Desc`,
                                                     `A`.`Grower`           AS `Grower`,
                                                     `A`.`FarmDesc`         AS `FarmDesc`,
                                                     `A`.`BlockDesc`        AS `BlockDesc`,
                                                     2017                   AS `cropYear`,
                                                     NULL                   AS `date_Changed`,
                                                     NULL                   AS `changed_by`,
                                                     `A`.`2017est`          AS `new_bushel_value`,
                                                     `A`.`isSameAsLastYear` AS `isSameAsLastYear`,
                                                     `A`.`isDeleted`        AS `isDeleted`,
                                                     `A`.`isFinished`       AS `isFinished`
                                                   from (`growerReporting`.`crop-estimates` `A` left join `growerReporting`.`crop_estimates_changes_timeseries` `B` on (`A`.`PK` = `B`.`block_PK`))
                                                   where `A`.`isDeleted` = 0 and `B`.`block_PK` is null;

