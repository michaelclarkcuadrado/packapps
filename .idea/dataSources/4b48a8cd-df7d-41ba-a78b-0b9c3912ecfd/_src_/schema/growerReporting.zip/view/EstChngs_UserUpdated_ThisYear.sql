CREATE VIEW EstChngs_UserUpdated_ThisYear AS
  SELECT
    `A`.`block_PK`          AS `block_PK`,
    `A`.`Comm Desc`         AS `Comm Desc`,
    `A`.`VarDesc`           AS `VarDesc`,
    `A`.`Str Desc`          AS `Str Desc`,
    `A`.`belongs_to_Grower` AS `Grower`,
    `A`.`FarmDesc`          AS `FarmDesc`,
    `A`.`BlockDesc`         AS `BlockDesc`,
    `A`.`cropYear`          AS `cropYear`,
    `A`.`date_Changed`      AS `date_Changed`,
    `A`.`changed_by`        AS `changed_by`,
    `A`.`new_bushel_value`  AS `new_bushel_value`
  FROM (`growerReporting`.`changes_this_year` `A`
    JOIN `growerReporting`.`EstChngs_DateOfLastManual_byBlock` `B`
      ON (`A`.`block_PK` = `B`.`block_PK` AND `A`.`date_Changed` = `B`.`Last_Date_Change`))
  UNION SELECT
          `A`.`PK`        AS `block_PK`,
          `A`.`Comm Desc` AS `Comm Desc`,
          `A`.`VarDesc`   AS `VarDesc`,
          `A`.`Str Desc`  AS `Str Desc`,
          `A`.`Grower`    AS `Grower`,
          `A`.`FarmDesc`  AS `FarmDesc`,
          `A`.`BlockDesc` AS `BlockDesc`,
          2017            AS `cropYear`,
          NULL            AS `date_Changed`,
          NULL            AS `changed_by`,
          `A`.`2017est`   AS `new_bushel_value`
        FROM `growerReporting`.`crop-estimates` `A`
        WHERE `A`.`isDeleted` = 0 AND `A`.`isSameAsLastYear` = 1;
