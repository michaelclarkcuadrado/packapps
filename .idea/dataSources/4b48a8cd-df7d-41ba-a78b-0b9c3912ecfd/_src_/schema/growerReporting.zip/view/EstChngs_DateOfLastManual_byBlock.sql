CREATE VIEW EstChngs_DateOfLastManual_byBlock AS
  SELECT
    `A1`.`block_PK`          AS `block_PK`,
    max(`A1`.`date_Changed`) AS `Last_Date_Change`
  FROM `growerReporting`.`changes_this_year` `A1`
  WHERE `A1`.`changed_by` <> 'System'
  GROUP BY `A1`.`block_PK`;
