CREATE VIEW operationsData.Block_Receiving AS
  SELECT
    trim(`operationsData`.`BULKOHCSV`.`Grower`)                AS `Grower`,
    trim(`operationsData`.`BULKOHCSV`.`CommDesc`)              AS `CommDesc`,
    trim(`operationsData`.`BULKOHCSV`.`FarmDesc`)              AS `Farm`,
    trim(`operationsData`.`BULKOHCSV`.`BlockDesc`)             AS `Block`,
    trim(`operationsData`.`BULKOHCSV`.`VarDesc`)               AS `VarDesc`,
    trim(`operationsData`.`BULKOHCSV`.`StrDesc`)               AS `Strain`,
    round(avg(`operationsData`.`AppleSamples`.`Pressure1`), 3) AS `Pressure1`,
    round(avg(`operationsData`.`AppleSamples`.`Pressure2`), 2) AS `Pressure2`,
    round(avg(`operationsData`.`AppleSamples`.`Brix`), 2)      AS `Brix`,
    round(avg(`operationsData`.`AppleSamples`.`DA`), 2)        AS `DA`,
    round(avg(`operationsData`.`AppleSamples`.`DA2`), 2)       AS `DA2`,
    count(0)                                                   AS `Count`,
    round(avg(`operationsData`.`AppleSamples`.`Weight`), 2)    AS `Weight`,
    round(avg(`operationsData`.`AppleSamples`.`Starch`), 2)    AS `Starch`
  FROM (`operationsData`.`AppleSamples`
    JOIN `operationsData`.`BULKOHCSV` ON (`operationsData`.`AppleSamples`.`RT#` = `operationsData`.`BULKOHCSV`.`RT#`))
  WHERE year(`operationsData`.`AppleSamples`.`FinalInspectionDate`) = year(curdate())
  GROUP BY `operationsData`.`BULKOHCSV`.`Grower`, `operationsData`.`BULKOHCSV`.`FarmDesc`,
    `operationsData`.`BULKOHCSV`.`BlockDesc`, `operationsData`.`BULKOHCSV`.`VarDesc`,
    `operationsData`.`BULKOHCSV`.`StrDesc`;
