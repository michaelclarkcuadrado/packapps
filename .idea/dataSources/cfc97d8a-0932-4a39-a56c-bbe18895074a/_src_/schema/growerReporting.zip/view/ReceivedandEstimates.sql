CREATE VIEW ReceivedandEstimates AS
  (SELECT
     rtrim(`growerReporting`.`crop-estimates`.`PK`)        AS `BlockID`,
     rtrim(`growerReporting`.`crop-estimates`.`Grower`)    AS `Code`,
     rtrim(`growerReporting`.`crop-estimates`.`Comm Desc`) AS `Commodity`,
     rtrim(`growerReporting`.`crop-estimates`.`FarmDesc`)  AS `Farm`,
     ifnull(rtrim(`CurYearReceived`.`Farm`), '')           AS `FarmCode`,
     rtrim(`growerReporting`.`crop-estimates`.`BlockDesc`) AS `Block`,
     ifnull(rtrim(`CurYearReceived`.`Block`), '')          AS `BlockCode`,
     rtrim(`growerReporting`.`crop-estimates`.`VarDesc`)   AS `Variety`,
     rtrim(`growerReporting`.`crop-estimates`.`Str Desc`)  AS `Strain`,
     rtrim(`growerReporting`.`crop-estimates`.`2014act`)   AS `2014 Received`,
     rtrim(`growerReporting`.`crop-estimates`.`2015act`)   AS `2015 Received`,
     rtrim(`growerReporting`.`crop-estimates`.`2016act`)   AS `2016 Received`,
     rtrim((CASE WHEN (`growerReporting`.`crop-estimates`.`isDeleted` = 0)
       THEN `growerReporting`.`crop-estimates`.`2016est`
            ELSE 0 END))                                   AS `2016 Estimate`,
     ifnull(sum(`CurYearReceived`.`Bu`), '0')              AS `2017 Received`,
     (CASE WHEN (`growerReporting`.`crop-estimates`.`isDeleted` = 0)
       THEN 'false'
      ELSE 'true' END)                                     AS `isDeletedBlock`,
     (CASE WHEN (`growerReporting`.`crop-estimates`.`isFinished` = 0)
       THEN 'false'
      ELSE 'true' END)                                     AS `isDonePicking`,
     (CASE WHEN ((`growerReporting`.`crop-estimates`.`2017est` <> `growerReporting`.`crop-estimates`.`2016act`) OR
                 (`growerReporting`.`crop-estimates`.`isSameAsLastYear` = 1))
       THEN 'true'
      ELSE 'false' END)                                    AS `isUserConfirmedEstimate`
   FROM (`growerReporting`.`crop-estimates`
     LEFT JOIN `growerReporting`.`CurYearReceived` ON ((
       (rtrim(`CurYearReceived`.`Comm Desc`) = rtrim(`growerReporting`.`crop-estimates`.`Comm Desc`)) AND
       rtrim((`CurYearReceived`.`VarDesc` = rtrim(`growerReporting`.`crop-estimates`.`VarDesc`))) AND
       rtrim((`CurYearReceived`.`StrDesc` = rtrim(`growerReporting`.`crop-estimates`.`Str Desc`))) AND
       rtrim((`CurYearReceived`.`BlockDesc` = rtrim(`growerReporting`.`crop-estimates`.`BlockDesc`))) AND
       rtrim((`CurYearReceived`.`FarmDesc` = rtrim(`growerReporting`.`crop-estimates`.`FarmDesc`))) AND
       rtrim((`CurYearReceived`.`Grower` = rtrim(`growerReporting`.`crop-estimates`.`Grower`))))))
   GROUP BY `growerReporting`.`crop-estimates`.`PK`)
  UNION (SELECT
           'Unmatched Block'                                AS `BlockID`,
           rtrim(`growerReporting`.`BULKRTCSV`.`Grower`)    AS `Code`,
           rtrim(`growerReporting`.`BULKRTCSV`.`Comm Desc`) AS `Commodity`,
           rtrim(`growerReporting`.`BULKRTCSV`.`FarmDesc`)  AS `Farm`,
           rtrim(`growerReporting`.`BULKRTCSV`.`Farm`)      AS `FarmCode`,
           rtrim(`growerReporting`.`BULKRTCSV`.`BlockDesc`) AS `Block`,
           rtrim(`growerReporting`.`BULKRTCSV`.`Block`)     AS `BlockCode`,
           rtrim(`growerReporting`.`BULKRTCSV`.`VarDesc`)   AS `Variety`,
           rtrim(`growerReporting`.`BULKRTCSV`.`StrDesc`)   AS `Strain`,
           '0'                                              AS `2014 Received`,
           '0'                                              AS `2015 Received`,
           '0'                                              AS `2016 Received`,
           '0'                                              AS `2017 Estimate`,
           sum(`growerReporting`.`BULKRTCSV`.`Bu`)          AS `2017 Received`,
           'false'                                          AS `isDeletedBlock`,
           'false'                                          AS `isDonePicking`,
           'false'                                          AS `isUserConfirmedEstimate`
         FROM (`growerReporting`.`BULKRTCSV`
           LEFT JOIN `growerReporting`.`crop-estimates` ON ((
             (rtrim(`growerReporting`.`BULKRTCSV`.`Comm Desc`) = rtrim(`growerReporting`.`crop-estimates`.`Comm Desc`))
             AND rtrim((`growerReporting`.`BULKRTCSV`.`VarDesc` = rtrim(`growerReporting`.`crop-estimates`.`VarDesc`)))
             AND rtrim((`growerReporting`.`BULKRTCSV`.`StrDesc` = rtrim(`growerReporting`.`crop-estimates`.`Str Desc`)))
             AND
             rtrim((`growerReporting`.`BULKRTCSV`.`BlockDesc` = rtrim(`growerReporting`.`crop-estimates`.`BlockDesc`)))
             AND
             rtrim((`growerReporting`.`BULKRTCSV`.`FarmDesc` = rtrim(`growerReporting`.`crop-estimates`.`FarmDesc`)))
             AND rtrim((`growerReporting`.`BULKRTCSV`.`Grower` = rtrim(`growerReporting`.`crop-estimates`.`Grower`))))))
         WHERE (isnull(`growerReporting`.`crop-estimates`.`PK`) AND
                (`growerReporting`.`BULKRTCSV`.`Crop Year` = substr(year(curdate()), 4, 1)))
         GROUP BY `growerReporting`.`BULKRTCSV`.`Grower`, `growerReporting`.`BULKRTCSV`.`Comm Desc`,
           `growerReporting`.`BULKRTCSV`.`FarmDesc`, `growerReporting`.`BULKRTCSV`.`BlockDesc`,
           `growerReporting`.`BULKRTCSV`.`VarDesc`, `growerReporting`.`BULKRTCSV`.`StrDesc`);
