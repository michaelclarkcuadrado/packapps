CREATE VIEW changes_this_year AS
  SELECT
    `growerReporting`.`crop_estimates_changes_timeseries`.`block_PK`          AS `block_PK`,
    `growerReporting`.`crop-estimates`.`Comm Desc`                            AS `Comm Desc`,
    `growerReporting`.`crop-estimates`.`VarDesc`                              AS `VarDesc`,
    `growerReporting`.`crop-estimates`.`FarmDesc`                             AS `FarmDesc`,
    `growerReporting`.`crop-estimates`.`BlockDesc`                            AS `BlockDesc`,
    `growerReporting`.`crop-estimates`.`Str Desc`                             AS `Str Desc`,
    `growerReporting`.`crop_estimates_changes_timeseries`.`date_Changed`      AS `date_Changed`,
    `growerReporting`.`crop_estimates_changes_timeseries`.`cropYear`          AS `cropYear`,
    `growerReporting`.`crop_estimates_changes_timeseries`.`belongs_to_Grower` AS `belongs_to_Grower`,
    `growerReporting`.`crop_estimates_changes_timeseries`.`changed_by`        AS `changed_by`,
    `growerReporting`.`crop_estimates_changes_timeseries`.`new_bushel_value`  AS `new_bushel_value`
  FROM (`growerReporting`.`crop_estimates_changes_timeseries`
    JOIN `growerReporting`.`crop-estimates`
      ON (`growerReporting`.`crop_estimates_changes_timeseries`.`block_PK` = `growerReporting`.`crop-estimates`.`PK`))
  WHERE year(`growerReporting`.`crop_estimates_changes_timeseries`.`date_Changed`) = year(current_timestamp());
