CREATE VIEW CurYearReceived AS
  (SELECT
     `growerReporting`.`BULKRTCSV`.`RT#`        AS `RT#`,
     `growerReporting`.`BULKRTCSV`.`Sort Code`  AS `Sort Code`,
     `growerReporting`.`BULKRTCSV`.`Crop Year`  AS `Crop Year`,
     `growerReporting`.`BULKRTCSV`.`Grower`     AS `Grower`,
     `growerReporting`.`BULKRTCSV`.`GrowerName` AS `GrowerName`,
     `growerReporting`.`BULKRTCSV`.`Class`      AS `Class`,
     `growerReporting`.`BULKRTCSV`.`ClassDesc`  AS `ClassDesc`,
     `growerReporting`.`BULKRTCSV`.`Commodity`  AS `Commodity`,
     `growerReporting`.`BULKRTCSV`.`Comm Desc`  AS `Comm Desc`,
     `growerReporting`.`BULKRTCSV`.`Variety`    AS `Variety`,
     `growerReporting`.`BULKRTCSV`.`VarDesc`    AS `VarDesc`,
     `growerReporting`.`BULKRTCSV`.`Strain`     AS `Strain`,
     `growerReporting`.`BULKRTCSV`.`StrDesc`    AS `StrDesc`,
     `growerReporting`.`BULKRTCSV`.`Farm`       AS `Farm`,
     `growerReporting`.`BULKRTCSV`.`FarmDesc`   AS `FarmDesc`,
     `growerReporting`.`BULKRTCSV`.`Block`      AS `Block`,
     `growerReporting`.`BULKRTCSV`.`BlockDesc`  AS `BlockDesc`,
     `growerReporting`.`BULKRTCSV`.`Lot`        AS `Lot`,
     `growerReporting`.`BULKRTCSV`.`Date`       AS `Date`,
     `growerReporting`.`BULKRTCSV`.`Pack`       AS `Pack`,
     `growerReporting`.`BULKRTCSV`.`Size`       AS `Size`,
     `growerReporting`.`BULKRTCSV`.`Qty`        AS `Qty`,
     `growerReporting`.`BULKRTCSV`.`Bu`         AS `Bu`,
     `growerReporting`.`BULKRTCSV`.`ItemNum`    AS `ItemNum`
   FROM `growerReporting`.`BULKRTCSV`
   WHERE `growerReporting`.`BULKRTCSV`.`Crop Year` = convert(substr(year(curdate()), 4, 1) USING latin1));
