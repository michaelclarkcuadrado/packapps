CREATE VIEW Estimates_AllBlocks_ThisYear AS
  SELECT
    `A`.`PK`               AS `block_PK`,
    `A`.`Comm Desc`        AS `Comm Desc`,
    `A`.`VarDesc`          AS `VarDesc`,
    `A`.`Str Desc`         AS `Str Desc`,
    `A`.`Grower`           AS `Grower`,
    `A`.`FarmDesc`         AS `FarmDesc`,
    `A`.`BlockDesc`        AS `BlockDesc`,
    `A`.`2016act`          AS `2016Act`,
    `B`.`new_bushel_value` AS `2017Est`,
    `B`.`changed_by`       AS `changed_by`,
    `B`.`date_Changed`     AS `date_Changed`
  FROM (`growerReporting`.`crop-estimates` `A` LEFT JOIN `growerReporting`.`EstChngs_UserUpdated_ThisYear` `B`
      ON (`A`.`PK` = `B`.`block_PK`));
