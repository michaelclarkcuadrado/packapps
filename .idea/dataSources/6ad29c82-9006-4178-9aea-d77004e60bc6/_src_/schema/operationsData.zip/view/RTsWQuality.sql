CREATE VIEW operationsData.RTsWQuality AS
  SELECT
    `operationsData`.`BULKOHCSV`.`RT#`                                                                      AS `RT#`,
    `operationsData`.`BULKOHCSV`.`SortCode`                                                                 AS `SortCode`,
    `operationsData`.`BULKOHCSV`.`CropYear`                                                                 AS `Crop Year`,
    `operationsData`.`BULKOHCSV`.`Grower`                                                                   AS `Grower`,
    `operationsData`.`BULKOHCSV`.`GrowerName`                                                               AS `Grower Name`,
    `operationsData`.`BULKOHCSV`.`Class`                                                                    AS `Class`,
    `operationsData`.`BULKOHCSV`.`ClassDesc`                                                                AS `Class Desc`,
    `operationsData`.`BULKOHCSV`.`Commodity`                                                                AS `Commodity`,
    `operationsData`.`BULKOHCSV`.`CommDesc`                                                                 AS `CommDesc`,
    `operationsData`.`BULKOHCSV`.`Variety`                                                                  AS `Variety`,
    `operationsData`.`BULKOHCSV`.`VarDesc`                                                                  AS `Var Desc`,
    `operationsData`.`BULKOHCSV`.`Strain`                                                                   AS `Strain`,
    `operationsData`.`BULKOHCSV`.`StrDesc`                                                                  AS `Str Desc`,
    `operationsData`.`BULKOHCSV`.`Farm`                                                                     AS `Farm`,
    CASE WHEN `operationsData`.`BULKOHCSV`.`FarmDesc` = ''
      THEN '[Farm Name]'
    ELSE `operationsData`.`BULKOHCSV`.`FarmDesc` END                                                        AS `Farm Desc`,
    `operationsData`.`BULKOHCSV`.`Block`                                                                    AS `Block`,
    CASE WHEN `operationsData`.`BULKOHCSV`.`BlockDesc` = ''
      THEN '[Block Name]'
    ELSE `operationsData`.`BULKOHCSV`.`BlockDesc` END                                                       AS `Block Desc`,
    `operationsData`.`BULKOHCSV`.`Lot`                                                                      AS `Lot`,
    `operationsData`.`BULKOHCSV`.`Date`                                                                     AS `Date`,
    `operationsData`.`BULKOHCSV`.`Size`                                                                     AS `Size`,
    `operationsData`.`BULKOHCSV`.`Pack`                                                                     AS `Pack`,
    `operationsData`.`BULKOHCSV`.`QtyOnHand`                                                                AS `QtyOnHand`,
    `operationsData`.`BULKOHCSV`.`BuOnHand`                                                                 AS `BuOnHand`,
    `operationsData`.`BULKOHCSV`.`RoomNum`                                                                  AS `Location`,
    `operationsData`.`BULKOHCSV`.`CoNum`                                                                    AS `Co#`,
    `operationsData`.`BULKOHCSV`.`Company Name`                                                             AS `Company Name`,
    CASE WHEN `operationsData`.`quality_InspectedRTs`.`Color Quality` IS NULL
      THEN 'FALSE'
    ELSE 'TRUE' END                                                                                         AS `isQA`,
    CASE WHEN `operationsData`.`quality_AppleSamples`.`PrAvg` IS NULL
      THEN ''
    ELSE round(avg(`operationsData`.`quality_AppleSamples`.`PrAvg`),
               3) END                                                                                       AS `PressureAvg`,
    CASE WHEN `operationsData`.`quality_AppleSamples`.`DAAvg` IS NULL
      THEN ''
    ELSE round(avg(`operationsData`.`quality_AppleSamples`.`DAAvg`), 2) END                                 AS `DAAvg`,
    ifnull(round(avg(`operationsData`.`quality_AppleSamples`.`Brix`), 2), '')                               AS `Brix`,
    ifnull(round(avg(`operationsData`.`quality_AppleSamples`.`Starch`), 1), '')                             AS `Starch`,
    ifnull(concat(`operationsData`.`quality_InspectedRTs`.`Color Quality`,
                  convert(CASE WHEN `operationsData`.`quality_InspectedRTs`.`Blush` <> 0
                    THEN ' With Blush'
                          ELSE '' END USING latin1)), '')                                                   AS `Color`,
    ifnull(`operationsData`.`quality_InspectedRTs`.`Bruise`, '')                                            AS `Bruise`,
    CASE WHEN `operationsData`.`quality_InspectedRTs`.`BitterPit` IS NULL
      THEN ''
    ELSE CASE WHEN `operationsData`.`quality_InspectedRTs`.`BitterPit` <> 0
      THEN 'Present'
         ELSE 'Not Present' END END                                                                         AS `BitterPit`,
    ifnull(`operationsData`.`quality_InspectedRTs`.`Russet`, '')                                            AS `Russet`,
    ifnull(`operationsData`.`quality_InspectedRTs`.`SunBurn`,
           '')                                                                                              AS `Sunburn`,
    ifnull(`operationsData`.`quality_InspectedRTs`.`SanJoseScale`,
           '')                                                                                              AS `San Jose Scale`,
    ifnull(`operationsData`.`quality_InspectedRTs`.`Scab`, '')                                              AS `Scab`,
    ifnull(`operationsData`.`quality_InspectedRTs`.`StinkBug`,
           '')                                                                                              AS `StinkBug`,
    ifnull(round(`AvgWeightByRT`.`WeightAvg`, 2),
           '')                                                                                              AS `AverageWeight`,
    CASE WHEN `AvgWeightByRT`.`WeightAvg` IS NULL
      THEN ''
    ELSE CASE WHEN `AvgWeightByRT`.`WeightAvg` * 16 >= 13
      THEN 48
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 13 AND `AvgWeightByRT`.`WeightAvg` >= 11.15)
           THEN 56
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 11.15 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 9.9)
           THEN 64
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 9.9 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 8.85)
           THEN 72
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 8.85 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 8)
           THEN 80
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 8 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 7.15)
           THEN 88
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 7.15 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 6.3)
           THEN 100
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 6.3 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 5.65)
           THEN 113
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 5.65 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 5.1)
           THEN 125
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 5.1 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 4.65)
           THEN 138
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 4.65 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 4.3)
           THEN 150
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 4.3 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 3.95)
           THEN 163
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 3.95 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 3.6)
           THEN 175
         WHEN (`AvgWeightByRT`.`WeightAvg` * 16 < 3.6 AND `AvgWeightByRT`.`WeightAvg` * 16 >= 3.25)
           THEN 198
         ELSE 216 END END                                                                                   AS `SizefromAverage`,
    ifnull(`operationsData`.`quality_InspectedRTs`.`Note`, '')                                              AS `Notes`,
    CASE WHEN `operationsData`.`quality_InspectedRTs`.`InspectedBy` IS NULL
      THEN ''
    ELSE concat('Field Inspector: ', `operationsData`.`quality_InspectedRTs`.`InspectedBy`, '-- Final Inspector: ',
                ifnull(`operationsData`.`quality_AppleSamples`.`FinalTestedBy`,
                       'Not Final Inspected')) END                                                          AS `InspectedBy`,
    ifnull(`operationsData`.`quality_AppleSamples`.`FinalInspectionDate`,
           ifnull(`operationsData`.`quality_InspectedRTs`.`DateInspected`,
                  ''))                                                                                      AS `DateTested`
  FROM (((`operationsData`.`BULKOHCSV`
    LEFT JOIN `operationsData`.`quality_InspectedRTs`
      ON (`operationsData`.`BULKOHCSV`.`RT#` = `operationsData`.`quality_InspectedRTs`.`RTNum`)) LEFT JOIN
    `operationsData`.`quality_AppleSamples`
      ON (`operationsData`.`quality_InspectedRTs`.`RTNum` = `operationsData`.`quality_AppleSamples`.`RT#`)) LEFT JOIN
    `operationsData`.`AvgWeightByRT` ON (`AvgWeightByRT`.`RTNum` = `operationsData`.`BULKOHCSV`.`RT#`))
  GROUP BY `operationsData`.`BULKOHCSV`.`RT#`;
