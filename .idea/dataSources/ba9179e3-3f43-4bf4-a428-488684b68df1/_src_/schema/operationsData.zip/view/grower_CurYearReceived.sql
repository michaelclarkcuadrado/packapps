CREATE VIEW grower_CurYearReceived AS
  (SELECT
     `operationsData`.`BULKRTCSV`.`RT#`        AS `RT#`,
     `operationsData`.`BULKRTCSV`.`Sort Code`  AS `Sort Code`,
     `operationsData`.`BULKRTCSV`.`Crop Year`  AS `Crop Year`,
     `operationsData`.`BULKRTCSV`.`Grower`     AS `Grower`,
     `operationsData`.`BULKRTCSV`.`GrowerName` AS `GrowerName`,
     `operationsData`.`BULKRTCSV`.`Class`      AS `Class`,
     `operationsData`.`BULKRTCSV`.`ClassDesc`  AS `ClassDesc`,
     `operationsData`.`BULKRTCSV`.`Commodity`  AS `Commodity`,
     `operationsData`.`BULKRTCSV`.`Comm Desc`  AS `Comm Desc`,
     `operationsData`.`BULKRTCSV`.`Variety`    AS `Variety`,
     `operationsData`.`BULKRTCSV`.`VarDesc`    AS `VarDesc`,
     `operationsData`.`BULKRTCSV`.`Strain`     AS `Strain`,
     `operationsData`.`BULKRTCSV`.`StrDesc`    AS `StrDesc`,
     `operationsData`.`BULKRTCSV`.`Farm`       AS `Farm`,
     `operationsData`.`BULKRTCSV`.`FarmDesc`   AS `FarmDesc`,
     `operationsData`.`BULKRTCSV`.`Block`      AS `Block`,
     `operationsData`.`BULKRTCSV`.`BlockDesc`  AS `BlockDesc`,
     `operationsData`.`BULKRTCSV`.`Lot`        AS `Lot`,
     `operationsData`.`BULKRTCSV`.`Date`       AS `Date`,
     `operationsData`.`BULKRTCSV`.`Pack`       AS `Pack`,
     `operationsData`.`BULKRTCSV`.`Size`       AS `Size`,
     `operationsData`.`BULKRTCSV`.`Qty`        AS `Qty`,
     `operationsData`.`BULKRTCSV`.`Bu`         AS `Bu`,
     `operationsData`.`BULKRTCSV`.`ItemNum`    AS `ItemNum`
   FROM `operationsData`.`BULKRTCSV`
   WHERE `operationsData`.`BULKRTCSV`.`Crop Year` = convert(substr(year(curdate()), 4, 1) USING latin1));
