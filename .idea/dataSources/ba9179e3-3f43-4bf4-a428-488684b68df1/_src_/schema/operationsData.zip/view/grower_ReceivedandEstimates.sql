CREATE VIEW grower_ReceivedandEstimates AS
  (SELECT
     rtrim(`operationsData`.`grower_crop-estimates`.`PK`)        AS `BlockID`,
     rtrim(`operationsData`.`grower_crop-estimates`.`Grower`)    AS `Code`,
     rtrim(`operationsData`.`grower_crop-estimates`.`Comm Desc`) AS `Commodity`,
     rtrim(`operationsData`.`grower_crop-estimates`.`FarmDesc`)  AS `Farm`,
     ifnull(rtrim(`grower_CurYearReceived`.`Farm`), '')          AS `FarmCode`,
     rtrim(`operationsData`.`grower_crop-estimates`.`BlockDesc`) AS `Block`,
     ifnull(rtrim(`grower_CurYearReceived`.`Block`), '')         AS `BlockCode`,
     rtrim(`operationsData`.`grower_crop-estimates`.`VarDesc`)   AS `Variety`,
     rtrim(`operationsData`.`grower_crop-estimates`.`Str Desc`)  AS `Strain`,
     rtrim(`operationsData`.`grower_crop-estimates`.`2014act`)   AS `2014 Received`,
     rtrim(`operationsData`.`grower_crop-estimates`.`2015act`)   AS `2015 Received`,
     rtrim(`operationsData`.`grower_crop-estimates`.`2016act`)   AS `2016 Received`,
     rtrim(CASE WHEN `operationsData`.`grower_crop-estimates`.`isDeleted` = 0
       THEN `operationsData`.`grower_crop-estimates`.`2016est`
           ELSE 0 END)                                           AS `2016 Estimate`,
     ifnull(sum(`grower_CurYearReceived`.`Bu`), '0')             AS `2017 Received`,
     CASE WHEN `operationsData`.`grower_crop-estimates`.`isDeleted` = 0
       THEN 'false'
     ELSE 'true' END                                             AS `isDeletedBlock`,
     CASE WHEN `operationsData`.`grower_crop-estimates`.`isFinished` = 0
       THEN 'false'
     ELSE 'true' END                                             AS `isDonePicking`,
     CASE WHEN (`operationsData`.`grower_crop-estimates`.`2017est` <> `operationsData`.`grower_crop-estimates`.`2016act`
                OR `operationsData`.`grower_crop-estimates`.`isSameAsLastYear` = 1)
       THEN 'true'
     ELSE 'false' END                                            AS `isUserConfirmedEstimate`
   FROM (`operationsData`.`grower_crop-estimates`
     LEFT JOIN `operationsData`.`grower_CurYearReceived` ON (
       rtrim(`grower_CurYearReceived`.`Comm Desc`) = rtrim(`operationsData`.`grower_crop-estimates`.`Comm Desc`) AND
       rtrim(`grower_CurYearReceived`.`VarDesc` = rtrim(`operationsData`.`grower_crop-estimates`.`VarDesc`)) AND
       rtrim(`grower_CurYearReceived`.`StrDesc` = rtrim(`operationsData`.`grower_crop-estimates`.`Str Desc`)) AND
       rtrim(`grower_CurYearReceived`.`BlockDesc` = rtrim(`operationsData`.`grower_crop-estimates`.`BlockDesc`)) AND
       rtrim(`grower_CurYearReceived`.`FarmDesc` = rtrim(`operationsData`.`grower_crop-estimates`.`FarmDesc`)) AND
       rtrim(`grower_CurYearReceived`.`Grower` = rtrim(`operationsData`.`grower_crop-estimates`.`Grower`))))
   GROUP BY `operationsData`.`grower_crop-estimates`.`PK`)
  UNION (SELECT
           'Unmatched Block'                               AS `BlockID`,
           rtrim(`operationsData`.`BULKRTCSV`.`Grower`)    AS `Code`,
           rtrim(`operationsData`.`BULKRTCSV`.`Comm Desc`) AS `Commodity`,
           rtrim(`operationsData`.`BULKRTCSV`.`FarmDesc`)  AS `Farm`,
           rtrim(`operationsData`.`BULKRTCSV`.`Farm`)      AS `FarmCode`,
           rtrim(`operationsData`.`BULKRTCSV`.`BlockDesc`) AS `Block`,
           rtrim(`operationsData`.`BULKRTCSV`.`Block`)     AS `BlockCode`,
           rtrim(`operationsData`.`BULKRTCSV`.`VarDesc`)   AS `Variety`,
           rtrim(`operationsData`.`BULKRTCSV`.`StrDesc`)   AS `Strain`,
           '0'                                             AS `2014 Received`,
           '0'                                             AS `2015 Received`,
           '0'                                             AS `2016 Received`,
           '0'                                             AS `2017 Estimate`,
           sum(`operationsData`.`BULKRTCSV`.`Bu`)          AS `2017 Received`,
           'false'                                         AS `isDeletedBlock`,
           'false'                                         AS `isDonePicking`,
           'false'                                         AS `isUserConfirmedEstimate`
         FROM (`operationsData`.`BULKRTCSV`
           LEFT JOIN `operationsData`.`grower_crop-estimates` ON (rtrim(`operationsData`.`BULKRTCSV`.`Comm Desc`) =
                                                                  rtrim(
                                                                      `operationsData`.`grower_crop-estimates`.`Comm Desc`)
                                                                  AND rtrim(`operationsData`.`BULKRTCSV`.`VarDesc` =
                                                                            rtrim(
                                                                                `operationsData`.`grower_crop-estimates`.`VarDesc`))
                                                                  AND rtrim(`operationsData`.`BULKRTCSV`.`StrDesc` =
                                                                            rtrim(
                                                                                `operationsData`.`grower_crop-estimates`.`Str Desc`))
                                                                  AND rtrim(`operationsData`.`BULKRTCSV`.`BlockDesc` =
                                                                            rtrim(
                                                                                `operationsData`.`grower_crop-estimates`.`BlockDesc`))
                                                                  AND rtrim(`operationsData`.`BULKRTCSV`.`FarmDesc` =
                                                                            rtrim(
                                                                                `operationsData`.`grower_crop-estimates`.`FarmDesc`))
                                                                  AND rtrim(`operationsData`.`BULKRTCSV`.`Grower` =
                                                                            rtrim(
                                                                                `operationsData`.`grower_crop-estimates`.`Grower`))))
         WHERE `operationsData`.`grower_crop-estimates`.`PK` IS NULL AND
               `operationsData`.`BULKRTCSV`.`Crop Year` = convert(substr(year(curdate()), 4, 1) USING latin1)
         GROUP BY `operationsData`.`BULKRTCSV`.`Grower`, `operationsData`.`BULKRTCSV`.`Comm Desc`,
           `operationsData`.`BULKRTCSV`.`FarmDesc`, `operationsData`.`BULKRTCSV`.`BlockDesc`,
           `operationsData`.`BULKRTCSV`.`VarDesc`, `operationsData`.`BULKRTCSV`.`StrDesc`);
