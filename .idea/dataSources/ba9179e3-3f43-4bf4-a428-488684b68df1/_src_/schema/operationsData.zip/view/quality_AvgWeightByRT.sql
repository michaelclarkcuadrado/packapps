CREATE VIEW quality_AvgWeightByRT AS
  SELECT
    `operationsData`.`quality_InspectedRTs`.`RTNum`                           AS `RTNum`,
    CASE WHEN `operationsData`.`quality_AggregateWeightSamples`.`Weight` IS NOT NULL
      THEN (sum(`operationsData`.`quality_InspectedRTs`.`#Samples`) * avg(`operationsData`.`quality_AppleSamples`.`Weight`) +
            20 * count(`operationsData`.`quality_AggregateWeightSamples`.`RT#`) * avg(`operationsData`.`quality_AggregateWeightSamples`.`Weight` / 20)) /
           (sum(`operationsData`.`quality_InspectedRTs`.`#Samples`) + 20 * count(`operationsData`.`quality_AggregateWeightSamples`.`RT#`))
    ELSE ifnull(avg(`operationsData`.`quality_AppleSamples`.`Weight`), 0) END AS `WeightAvg`
  FROM ((`operationsData`.`quality_InspectedRTs`
    LEFT JOIN `operationsData`.`quality_AppleSamples` ON (`operationsData`.`quality_InspectedRTs`.`RTNum` = `operationsData`.`quality_AppleSamples`.`RT#`)) LEFT JOIN
    `operationsData`.`quality_AggregateWeightSamples` ON (`operationsData`.`quality_InspectedRTs`.`RTNum` = `operationsData`.`quality_AggregateWeightSamples`.`RT#`))
  GROUP BY `operationsData`.`quality_InspectedRTs`.`RTNum`;
