CREATE VIEW quality_Block_Receiving AS
  SELECT
    trim(`operationsData`.`BULKOHCSV`.`Grower`)                        AS `Grower`,
    trim(`operationsData`.`BULKOHCSV`.`CommDesc`)                      AS `CommDesc`,
    trim(`operationsData`.`BULKOHCSV`.`FarmDesc`)                      AS `Farm`,
    trim(`operationsData`.`BULKOHCSV`.`BlockDesc`)                     AS `Block`,
    trim(`operationsData`.`BULKOHCSV`.`VarDesc`)                       AS `VarDesc`,
    trim(`operationsData`.`BULKOHCSV`.`StrDesc`)                       AS `Strain`,
    round(avg(`operationsData`.`quality_AppleSamples`.`Pressure1`), 3) AS `Pressure1`,
    round(avg(`operationsData`.`quality_AppleSamples`.`Pressure2`), 2) AS `Pressure2`,
    round(avg(`operationsData`.`quality_AppleSamples`.`Brix`), 2)      AS `Brix`,
    round(avg(`operationsData`.`quality_AppleSamples`.`DA`), 2)        AS `DA`,
    round(avg(`operationsData`.`quality_AppleSamples`.`DA2`), 2)       AS `DA2`,
    count(0)                                                           AS `Count`,
    round(avg(`operationsData`.`quality_AppleSamples`.`Weight`), 2)    AS `Weight`,
    round(avg(`operationsData`.`quality_AppleSamples`.`Starch`), 2)    AS `Starch`
  FROM (`operationsData`.`quality_AppleSamples`
    JOIN `operationsData`.`BULKOHCSV`
      ON (`operationsData`.`quality_AppleSamples`.`RT#` = `operationsData`.`BULKOHCSV`.`RT#`))
  WHERE year(`operationsData`.`quality_AppleSamples`.`FinalInspectionDate`) = year(curdate())
  GROUP BY `operationsData`.`BULKOHCSV`.`Grower`, `operationsData`.`BULKOHCSV`.`FarmDesc`,
    `operationsData`.`BULKOHCSV`.`BlockDesc`, `operationsData`.`BULKOHCSV`.`VarDesc`,
    `operationsData`.`BULKOHCSV`.`StrDesc`;
