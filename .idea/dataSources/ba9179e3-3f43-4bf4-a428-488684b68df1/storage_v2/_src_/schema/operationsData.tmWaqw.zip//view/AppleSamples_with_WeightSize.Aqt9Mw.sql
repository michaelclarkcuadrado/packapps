create view AppleSamples_with_WeightSize as
  select `A`.`RT#`                 AS `RT#`,
         `A`.`SampleNum`           AS `SampleNum`,
         `A`.`Pressure1`           AS `Pressure1`,
         `A`.`Pressure2`           AS `Pressure2`,
         `A`.`DA`                  AS `DA`,
         `A`.`DA2`                 AS `DA2`,
         `A`.`Brix`                AS `Brix`,
         `A`.`Weight`              AS `Weight`,
         `A`.`Starch`              AS `Starch`,
         `A`.`FinalTestedBy`       AS `FinalTestedBy`,
         `A`.`FinalInspectionDate` AS `FinalInspectionDate`,
         `A`.`PrAvg`               AS `PrAvg`,
         `A`.`DAAvg`               AS `DAAvg`,
         `B`.`TP_Size`             AS `TP_Size`,
         `B`.`RPC_Size`            AS `RPC_Size`
  from ((`operationsData`.`AppleSamples` `A` left join `operationsData`.`BULKOHCSV` `C` on (`A`.`RT#` = `C`.`RT#`)) left join `operationsData`.`WeightSize` `B` on (
    `C`.`VarDesc` = convert(`B`.`Variety` using utf8) and `A`.`Weight` >= `B`.`min_weight` and `A`.`Weight` <= `B`.`max_weight`));

