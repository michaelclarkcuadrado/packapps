create view quality_AvgWeightByRT as
  select `operationsData`.`quality_InspectedRTs`.`RTNum`                             AS `RTNum`,
         case
           when `operationsData`.`quality_AggregateWeightSamples`.`Weight` is not null then
             (sum(`operationsData`.`quality_InspectedRTs`.`#Samples`) * avg(`operationsData`.`quality_AppleSamples`.`Weight`) +
              20 * count(`operationsData`.`quality_AggregateWeightSamples`.`RT#`) * avg(`operationsData`.`quality_AggregateWeightSamples`.`Weight` / 20)) /
             (sum(`operationsData`.`quality_InspectedRTs`.`#Samples`) + 20 * count(`operationsData`.`quality_AggregateWeightSamples`.`RT#`))
           else ifnull(avg(`operationsData`.`quality_AppleSamples`.`Weight`), 0) end AS `WeightAvg`
  from ((`operationsData`.`quality_InspectedRTs`
      left join `operationsData`.`quality_AppleSamples` on (`operationsData`.`quality_InspectedRTs`.`RTNum` =
                                                            `operationsData`.`quality_AppleSamples`.`RT#`)) left join `operationsData`.`quality_AggregateWeightSamples` on (
    `operationsData`.`quality_InspectedRTs`.`RTNum` = `operationsData`.`quality_AggregateWeightSamples`.`RT#`))
  group by `operationsData`.`quality_InspectedRTs`.`RTNum`;

