create view quality_RTsWQuality as
  select `operationsData`.`BULKOHCSV`.`RT#`                                                                                                         AS `RT#`,
         `operationsData`.`BULKOHCSV`.`SortCode`                                                                                                    AS `SortCode`,
         `operationsData`.`BULKOHCSV`.`CropYear`                                                                                                    AS `Crop Year`,
         `operationsData`.`BULKOHCSV`.`Grower`                                                                                                      AS `Grower`,
         `operationsData`.`BULKOHCSV`.`GrowerName`                                                                                                  AS `Grower Name`,
         `operationsData`.`BULKOHCSV`.`Class`                                                                                                       AS `Class`,
         `operationsData`.`BULKOHCSV`.`ClassDesc`                                                                                                   AS `Class Desc`,
         `operationsData`.`BULKOHCSV`.`Commodity`                                                                                                   AS `Commodity`,
         `operationsData`.`BULKOHCSV`.`CommDesc`                                                                                                    AS `CommDesc`,
         `operationsData`.`BULKOHCSV`.`Variety`                                                                                                     AS `Variety`,
         `operationsData`.`BULKOHCSV`.`VarDesc`                                                                                                     AS `Var Desc`,
         `operationsData`.`BULKOHCSV`.`Strain`                                                                                                      AS `Strain`,
         `operationsData`.`BULKOHCSV`.`StrDesc`                                                                                                     AS `Str Desc`,
         `operationsData`.`BULKOHCSV`.`Farm`                                                                                                        AS `Farm`,
         case
           when `operationsData`.`BULKOHCSV`.`FarmDesc` = '' then '[Farm Name]'
           else `operationsData`.`BULKOHCSV`.`FarmDesc` end                                                                                         AS `Farm Desc`,
         `operationsData`.`BULKOHCSV`.`Block`                                                                                                       AS `Block`,
         case
           when `operationsData`.`BULKOHCSV`.`BlockDesc` = '' then '[Block Name]'
           else `operationsData`.`BULKOHCSV`.`BlockDesc` end                                                                                        AS `Block Desc`,
         `operationsData`.`BULKOHCSV`.`Lot`                                                                                                         AS `Lot`,
         `operationsData`.`BULKOHCSV`.`Date`                                                                                                        AS `Date`,
         `operationsData`.`BULKOHCSV`.`Size`                                                                                                        AS `Size`,
         `operationsData`.`BULKOHCSV`.`Pack`                                                                                                        AS `Pack`,
         `operationsData`.`BULKOHCSV`.`QtyOnHand`                                                                                                   AS `QtyOnHand`,
         `operationsData`.`BULKOHCSV`.`BuOnHand`                                                                                                    AS `BuOnHand`,
         `operationsData`.`BULKOHCSV`.`RoomNum`                                                                                                     AS `Location`,
         `operationsData`.`BULKOHCSV`.`CoNum`                                                                                                       AS `Co#`,
         `operationsData`.`BULKOHCSV`.`Company Name`                                                                                                AS `Company Name`,
         case
           when `operationsData`.`quality_InspectedRTs`.`Color Quality` is null then 'FALSE'
           else 'TRUE' end                                                                                                                          AS `isQA`,
         case
           when `operationsData`.`quality_AppleSamples`.`PrAvg` is null then ''
           else round(avg(`operationsData`.`quality_AppleSamples`.`PrAvg`), 3) end                                                                  AS `PressureAvg`,
         case
           when `operationsData`.`quality_AppleSamples`.`DAAvg` is null then ''
           else round(avg(`operationsData`.`quality_AppleSamples`.`DAAvg`), 2) end                                                                  AS `DAAvg`,
         ifnull(round(avg(`operationsData`.`quality_AppleSamples`.`Brix`), 2), '')                                                                  AS `Brix`,
         ifnull(round(avg(`operationsData`.`quality_AppleSamples`.`Starch`), 1), '')                                                                AS `Starch`,
         ifnull(concat(`operationsData`.`quality_InspectedRTs`.`Color Quality`, convert(case
                                                                                          when `operationsData`.`quality_InspectedRTs`.`Blush` <> 0 then ' With Blush'
                                                                                          else '' end using latin1)), '')                           AS `Color`,
         ifnull(`operationsData`.`quality_InspectedRTs`.`Bruise`, '')                                                                               AS `Bruise`,
         case
           when `operationsData`.`quality_InspectedRTs`.`BitterPit` is null then ''
           else case
                  when `operationsData`.`quality_InspectedRTs`.`BitterPit` <> 0 then 'Present'
                  else 'Not Present' end end                                                                                                        AS `BitterPit`,
         ifnull(`operationsData`.`quality_InspectedRTs`.`Russet`, '')                                                                               AS `Russet`,
         ifnull(`operationsData`.`quality_InspectedRTs`.`SunBurn`, '')                                                                              AS `Sunburn`,
         ifnull(`operationsData`.`quality_InspectedRTs`.`SanJoseScale`, '')                                                                         AS `San Jose Scale`,
         ifnull(`operationsData`.`quality_InspectedRTs`.`Scab`, '')                                                                                 AS `Scab`,
         ifnull(`operationsData`.`quality_InspectedRTs`.`StinkBug`, '')                                                                             AS `StinkBug`,
         ifnull(round(`quality_AvgWeightByRT`.`WeightAvg`, 2), '')                                                                                  AS `AverageWeight`,
         case
           when `quality_AvgWeightByRT`.`WeightAvg` is null then ''
           else case
                  when `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 13 then 48
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 13 and `quality_AvgWeightByRT`.`WeightAvg` >= 11.15) then 56
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 11.15 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 9.9) then 64
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 9.9 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 8.85) then 72
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 8.85 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 8) then 80
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 8 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 7.15) then 88
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 7.15 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 6.3) then 100
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 6.3 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 5.65) then 113
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 5.65 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 5.1) then 125
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 5.1 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 4.65) then 138
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 4.65 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 4.3) then 150
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 4.3 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 3.95) then 163
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 3.95 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 3.6) then 175
                  when (`quality_AvgWeightByRT`.`WeightAvg` * 16 < 3.6 and `quality_AvgWeightByRT`.`WeightAvg` * 16 >= 3.25) then 198
                  else 216 end end                                                                                                                  AS `SizefromAverage`,
         ifnull(`operationsData`.`quality_InspectedRTs`.`Note`, '')                                                                                 AS `Notes`,
         case
           when `operationsData`.`quality_InspectedRTs`.`InspectedBy` is null then ''
           else concat('Field Inspector: ', `operationsData`.`quality_InspectedRTs`.`InspectedBy`, '-- Final Inspector: ',
                       ifnull(`operationsData`.`quality_AppleSamples`.`FinalTestedBy`, 'Not Final Inspected')) end                                  AS `InspectedBy`,
         ifnull(`operationsData`.`quality_AppleSamples`.`FinalInspectionDate`, ifnull(`operationsData`.`quality_InspectedRTs`.`DateInspected`, '')) AS `DateTested`
  from (((`operationsData`.`BULKOHCSV`
      left join `operationsData`.`quality_InspectedRTs` on (`operationsData`.`BULKOHCSV`.`RT#` =
                                                            `operationsData`.`quality_InspectedRTs`.`RTNum`)) left join `operationsData`.`quality_AppleSamples` on (
    `operationsData`.`quality_InspectedRTs`.`RTNum` = `operationsData`.`quality_AppleSamples`.`RT#`)) left join `operationsData`.`quality_AvgWeightByRT` on (`quality_AvgWeightByRT`.`RTNum` =
                                                                                                                                                             `operationsData`.`BULKOHCSV`.`RT#`))
  group by `operationsData`.`BULKOHCSV`.`RT#`;

