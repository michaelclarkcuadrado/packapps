CREATE VIEW `grower_gfbvs-listing` AS
  SELECT
    `operationsData`.`grower_crop-estimates`.`PK`          AS `PK`,
    `operationsData`.`grower_commodities`.`commodity_name` AS `commodity_name`,
    `operationsData`.`grower_GrowerLogins`.`GrowerName`    AS `GrowerName`,
    `operationsData`.`grower_farms`.`farmName`             AS `farmName`,
    `operationsData`.`grower_crop-estimates`.`BlockDesc`   AS `BlockDesc`,
    `operationsData`.`grower_varieties`.`VarietyName`      AS `VarietyName`,
    `operationsData`.`grower_strains`.`strainName`         AS `strainName`
  FROM (((((`operationsData`.`grower_crop-estimates`
    JOIN `operationsData`.`grower_farms` ON (`operationsData`.`grower_crop-estimates`.`farmID` = `operationsData`.`grower_farms`.`farmID`)) JOIN `operationsData`.`grower_GrowerLogins`
      ON (`operationsData`.`grower_farms`.`growerID` = `operationsData`.`grower_GrowerLogins`.`GrowerID`)) JOIN `operationsData`.`grower_strains`
      ON (`operationsData`.`grower_crop-estimates`.`strainID` = `operationsData`.`grower_strains`.`strain_ID`)) JOIN `operationsData`.`grower_varieties`
      ON (`operationsData`.`grower_strains`.`variety_ID` = `operationsData`.`grower_varieties`.`VarietyID`)) JOIN `operationsData`.`grower_commodities`
      ON (`operationsData`.`grower_varieties`.`commodityID` = `operationsData`.`grower_commodities`.`commodity_ID`))
  WHERE `operationsData`.`grower_crop-estimates`.`isDeleted` = 0;

