create view `grower_gfbvs-listing` as
  select `operationsData`.`grower_crop-estimates`.`PK`          AS `PK`,
         `operationsData`.`grower_commodities`.`commodity_name` AS `commodity_name`,
         `operationsData`.`grower_GrowerLogins`.`GrowerName`    AS `GrowerName`,
         `operationsData`.`grower_farms`.`farmName`             AS `farmName`,
         `operationsData`.`grower_crop-estimates`.`BlockDesc`   AS `BlockDesc`,
         `operationsData`.`grower_varieties`.`VarietyName`      AS `VarietyName`,
         `operationsData`.`grower_strains`.`strainName`         AS `strainName`
  from (((((`operationsData`.`grower_crop-estimates`
      join `operationsData`.`grower_farms` on (`operationsData`.`grower_crop-estimates`.`farmID` = `operationsData`.`grower_farms`.`farmID`)) join `operationsData`.`grower_GrowerLogins` on (
    `operationsData`.`grower_farms`.`growerID` = `operationsData`.`grower_GrowerLogins`.`GrowerID`)) join `operationsData`.`grower_strains` on (`operationsData`.`grower_crop-estimates`.`strainID` =
                                                                                                                                                `operationsData`.`grower_strains`.`strain_ID`)) join `operationsData`.`grower_varieties` on (
    `operationsData`.`grower_strains`.`variety_ID` = `operationsData`.`grower_varieties`.`VarietyID`)) join `operationsData`.`grower_commodities` on (`operationsData`.`grower_varieties`.`commodityID`
                                                                                                                                                      =
                                                                                                                                                      `operationsData`.`grower_commodities`.`commodity_ID`))
  where `operationsData`.`grower_crop-estimates`.`isDeleted` = 0;

